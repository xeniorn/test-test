""" Python interface to custome R scripts. """
from .limma import multi_group_limma, two_group_limma
from .rinstaller import r_package_version
